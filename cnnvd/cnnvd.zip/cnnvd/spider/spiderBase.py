#coding:utf8

#Author: tsuki
#Date: 2017-12-08
#Time: 15:40

class SpiderBase():

    def __init__(self):
        pass