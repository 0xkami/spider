import random
import requests
import re
import bs4


from config import Config
from spiderUtil import SpiderUtil

ua_list = ["Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
           "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 "
           "Safari/536.11",
           "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
           "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
           "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
           "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
           "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",
           "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
           "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
           "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 "
           "Safari/536.3",
           "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
           "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
           "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
           "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
           "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
           "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",
           "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
           "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24"
           ]

def spider(spider_url,cve):
    header = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Sec-Fetch-Mode': 'cors',
        'User-Agent': random.choice(ua_list),
        'X-Requested-With': 'XMLHttpRequest'
        }
    s = requests.session()
    s.headers.update(header)
    postData = {"CSRFToken": "", "cvHazardRating": "", "cvVultype": "", "qstartdateXq": "",
                "cvUsedStyle": "", "cvCnnvdUpdatedateXq": "", "cpvendor": "", "relLdKey": "",
                "hotLd": "", "isArea": "", "qcvCname": "", "qcvCnnvdid": cve, "qstartdate": "", "qenddate": ""}
    rs = s.post(spider_url, postData)
    pattern = re.compile(r'>CNNVD-.*<')
    m = pattern.finditer(rs.text)
    for match in m:
        s1 = match.group(0)
    s2 = s1.replace("<", "")
    cnnvd = s2.replace(">", "")
    return cnnvd
def getcnnvd(url):
    header = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Sec-Fetch-Mode': 'cors',
        'User-Agent': random.choice(ua_list),
        'X-Requested-With': 'XMLHttpRequest'
    }
    spider_request = requests.get(url, headers=header)
    h1 = spider_request.text
    #print(h1)
    pattern = re.compile(r'<meta name="title" content=".*"')
    m = pattern.finditer(h1)
    for match in m:
        s1 = match.group(0)
        print(s1)

def getDetailData(url):
    data = {}
    data['detailUrl'] = url
    soup = SpiderUtil().getSoup(url)
    details = soup.find('div', class_='detail_xq w770')
    data['chname'] = details.h2.getText()
    for li in details.ul:
        if type(li) == bs4.element.Tag:
            texts = re.sub("(\t)*", "", li.getText()).split("：")
            if texts[0] in Config().getCnnvdVulList():
                codeName = Config().getCnnvdVulList()[texts[0]]
                data[codeName] = texts[1]
                #print(codeName + ": " + data[codeName])
        # 漏洞简介
    vul_descriptions = soup.find('div', class_='d_ldjj').findAll('p', style='text-indent:2em')
    data['vul_description'] = ''
    for vul_description in vul_descriptions:
        data['vul_description'] += re.sub("(\t|\n|\r|\040)*", "", vul_description.getText())
        # 漏洞公告，参考网址，受影响实体
    contents = soup.findAll('div', class_='d_ldjj m_t_20')
    for content in contents:
        title = content.find('div', class_='title_bt').getText()
        title = re.sub("(\t|\n|\r|\040)*", "", title)
        if title in Config().getCnnvdVulList():
            codeName = Config().getCnnvdVulList()[title]
            data[codeName] = ''
            p = content.findAll('p', style='text-indent:2em')
            for x in p:
                data[codeName] += re.sub("(\t|\n|\r|\040)*", "", x.getText())
    #print(data)
    print(data['chname'])
    print(data['vul_description'])
    print(data['vul_announcement'])



if __name__ == '__main__':
    urlbase = 'http://www.cnnvd.org.cn/web/vulnerability/querylist.tag'
    cve = 'CVE-2021-31810'
    cnnvd = spider(urlbase, cve)
    url = 'http://www.cnnvd.org.cn/web/xxk/ldxqById.tag?CNNVD='
    urlf = url+cnnvd
    #print(urlf)
    getDetailData(urlf)


